import sys
from random import randint
from time import sleep

answer = ""


def say(text):
    print(text)


def ask(question):
    global answer
    answer = input(question)
    return answer


def wait(seconds):
    sleep(seconds)


def pick_random_number_from(a, b):
    return randint(a, b)


def stop_all():
    sys.exit(0)


# For anyone reading the code, I skipped the forever and repeat functions not because it is very glitchy: Cade
