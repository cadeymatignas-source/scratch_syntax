# Scratch_Syntax



## This is a custom Python library designed to handle scratch syntax formatting and parsing.



# Installation

```bash

pip install scratch_syntax

```

you can do anything with this library, mod it, break it, anything, but don't sue me

# Update 0.2.0 notes
I removed the forever and repeat functions and added the stop_all function. You can use **for _ in range():** for repeat and **while True:** for forever

# Updating

```bash

pip install --upgrade scratch_syntax

```