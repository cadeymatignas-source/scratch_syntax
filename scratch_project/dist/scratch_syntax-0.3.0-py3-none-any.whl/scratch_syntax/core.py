import sys
from random import randint
from time import sleep

answer = ""


def say(text):
    print(text)


def ask(question):
    global answer
    answer = input(question)
    return answer


def wait(seconds):
    sleep(seconds)


def pick_random_number_from(a, b):
    return randint(a, b)


def stop_all():
    sys.exit(0)


def add_to_list(listname, item):
    listname.append(item)


def insert_in_list(listname, index, item):
    listname.insert(index, item)


def delete_from_list(listname, index):
    del listname[index]


def delete_all_from_list(listname):
    listname.clear()


def replace_in_list(listname, index, item):
    listname[index] = item


# For anyone reading the code, I skipped the forever and repeat functions not because I wanted to but because it doesnt work: Cade
