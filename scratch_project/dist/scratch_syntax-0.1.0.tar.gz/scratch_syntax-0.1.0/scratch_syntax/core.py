from contextlib import contextmanager
from random import randint
from time import sleep

answer = ""


def say(text):
	print(text)


def ask(question):
	global answer
	answer = input(question)
	return answer


def wait(seconds):
	sleep(seconds)


def pick_random_number_from(a, b):
	return randint(a, b)


@contextmanager
def repeat(times):
	for _ in range(times):
		yield


@contextmanager
def forever():
	while True:
		yield
