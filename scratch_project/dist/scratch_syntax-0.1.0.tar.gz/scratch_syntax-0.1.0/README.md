\# Scratch Syntax



This is a custom Python library designed to handle scratch syntax formatting and parsing.



\## Installation

```bash

pip install scratch\_syntax

```

you can do anything with this library, mod it, break it, anything, but don't sue me

